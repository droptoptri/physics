Сайт для sgt-h.ru, REG.RU Хост-0.

Содержимое sgt-h.ru загрузите в корень сайта sgt-h.ru, включая .htaccess и .user.ini.
Папку sgt-private разместите РЯДОМ с папкой сайта, за пределами его корня.
НЕ загружайте sgt-private внутрь public.
Создайте в sgt-private файл install-password.txt со своим уникальным паролем от 20 символов, затем откройте https://sgt-h.ru/setup.
Подробно: https://github.com/droptoptri/physics/blob/main/docs/REG-RU.md
